package com.lom.WeirdNuke;

import net.minecraft.client.renderer.RenderBlocks;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.entity.Entity;
import net.minecraft.util.ResourceLocation;

import org.lwjgl.opengl.GL11;

import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderNuke extends Render
{
private RenderBlocks blockRenderer = new RenderBlocks();

public RenderNuke()
{
this.shadowSize = 0.5F;
}

public void renderPrimedTNT(EntityNuke par1EntityTNTBoxPrimed, double par2, double par4, double par6, float par8, float par9)
{
GL11.glPushMatrix();
GL11.glTranslatef((float)par2, (float)par4, (float)par6);
float var10;

if ((float)par1EntityTNTBoxPrimed.fuse - par9 + 1.0F < 10.0F)
{
var10 = 1.0F - ((float)par1EntityTNTBoxPrimed.fuse - par9 + 1.0F) / 10.0F;

if (var10 < 0.0F)
{
var10 = 0.0F;
}

if (var10 > 1.0F)
{
var10 = 1.0F;
}

var10 *= var10;
var10 *= var10;
float var11 = 1.0F + var10 * 0.3F;
GL11.glScalef(var11, var11, var11);
}

var10 = (1.0F - ((float)par1EntityTNTBoxPrimed.fuse - par9 + 1.0F) / 100.0F) * 0.8F;
this.bindEntityTexture(par1EntityTNTBoxPrimed);
this.blockRenderer.renderBlockAsItem(TNT.Nuke, 0, par1EntityTNTBoxPrimed.getBrightness(par9));
//this.getEntityTexture(TNTProxy.TNTBOX_PNG);
//this.blockRenderer.renderBlockAsItem(ModRegistry.tntbox, 0, par1EntityTNTBoxPrimed.getBrightness(par9));

if (par1EntityTNTBoxPrimed.fuse / 5 % 2 == 0)
{
GL11.glDisable(GL11.GL_TEXTURE_2D);
GL11.glDisable(GL11.GL_LIGHTING);
GL11.glEnable(GL11.GL_BLEND);
GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_DST_ALPHA);
GL11.glColor4f(1.0F, 1.0F, 1.0F, var10);
//this.blockRenderer.renderBlockAsItem(ModRegistry.tntbox, 0, 1.0F);
GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
GL11.glDisable(GL11.GL_BLEND);
GL11.glEnable(GL11.GL_LIGHTING);
GL11.glEnable(GL11.GL_TEXTURE_2D);
}

GL11.glPopMatrix();
}



protected ResourceLocation func_110808_a(EntityNuke par1EntityTNTPrimed)
{
    return TextureMap.locationBlocksTexture;
}

/**
 * Returns the location of an entity's texture. Doesn't seem to be called unless you call Render.bindEntityTexture.
 */
protected ResourceLocation getEntityTexture(Entity par1Entity)
{
    return this.func_110808_a((EntityNuke)par1Entity);
}

public void doRender(Entity par1Entity, double par2, double par4, double par6, float par8, float par9)
{
this.renderPrimedTNT((EntityNuke)par1Entity, par2, par4, par6, par8, par9);
}
}

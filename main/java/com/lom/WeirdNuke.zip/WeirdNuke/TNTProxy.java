package com.lom.WeirdNuke;

public class TNTProxy {
	
	public static String TNTBOX_PNG = "/minecraft/textures/blocks/MinerSide.png";

	public void registerRenderers () {
	}

	public void registerEntites() {
	}

	public void registerRenderInformation() {

	}

	

}

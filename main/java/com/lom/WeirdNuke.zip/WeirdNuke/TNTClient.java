package com.lom.WeirdNuke;

import cpw.mods.fml.client.registry.RenderingRegistry;
import cpw.mods.fml.relauncher.Side;
import cpw.mods.fml.relauncher.SideOnly;

public class TNTClient extends TNTProxy {
	
	 @SideOnly(Side.CLIENT)
	 public void registerRenderInformation()
	 {

		 RenderingRegistry.instance().registerEntityRenderingHandler(EntityNuke.class, new RenderNuke());

	        }

}

package com.lom.WeirdNuke;

import net.minecraft.block.Block;
import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.init.Blocks;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import cpw.mods.fml.common.Mod;
import cpw.mods.fml.common.Mod.EventHandler;
import cpw.mods.fml.common.SidedProxy;
import cpw.mods.fml.common.event.FMLInitializationEvent;
import cpw.mods.fml.common.registry.EntityRegistry;
import cpw.mods.fml.common.registry.GameRegistry;
import cpw.mods.fml.common.registry.LanguageRegistry;

@Mod (modid = "TNT",name = "TNT", version = "Just some :P (I'm too lazy to change this with every version)")

public class TNT {
	
	public static int MinerID = 150;
    public static int NukeID = 151;
    public static int NapalmID = 152;
    public static int FirebombID = 153;
    public static int ScatterBombID = 154;
    public static int ScatterBombExplodeID = 155;
    public static float NukeBlastRadius = 120.0F;
    public static int NukeFuse = 200;
    public static float MinerBlastRadius = 6.0F;
    public static int MinerFuse = 120;
    public static float NapalmBlastRadius = 4.0F;
    public static int NapalmFuse = 80;
    public static float FirebombBlastRadius = 4.0F;
    public static int FirebombFuse = 80;
    public static int ScatterBombFuse = 80;
    public static float ScatterBombBlastRadius = 1.0F;
    public static float ScatterBombExplodeBlastRadius = 60.0F;
    public static int ScatterBombExplodeFuse = 80;
    public static float ExplosionDamage = 2.0F;
	
    
	//public static CreativeTabs TNTTab = new TNTTab(CreativeTabs.getNextID(),"TNTTab");
	public static String modid = "TNT";
	
	@SidedProxy(clientSide = "com.lom.WeirdNuke.TNTClient",serverSide = "com.lom.WeirdNuke.TNTProxy")
	  public static TNTProxy proxy;
	
	//static EnumToolMaterial EnumToolMaterialRed= EnumHelper.addToolMaterial("RED", 1, 100, 2.1F, 1, 17);
	
	//public static final Item BlueBar = new Item(1000).setMaxStackSize(64).setUnlocalizedName("mmm1").setTextureName("blueBar").setCreativeTab(IMSM.Materials);
	//LanguageRegistry.addName(IMSM.BlueBar, "Blue B
	
	//public static Block Miner = new BlockMiner(180, 0).setHardness(0.0F).setUnlocalizedName("miner tnt").setTextureName("MinerTop").setCreativeTab(TNT.TNTTab);
	public static Block Nuke = (new BlockNuke(181, 0)).setHardness(0.0F).setBlockName("nuke").setBlockTextureName("NukeSide").setCreativeTab(CreativeTabs.tabBlock);
	//public static Block ScatterBomb = (new BlockScatterBomb(182, 0)).setHardness(0.0F).setUnlocalizedName("scatterbomb").setTextureName("ScatterBombSide")/**.setCreativeTab(TNT.TNTTab)*/;
	//public static Block ScatterBombExplode = (new BlockScatterBombExplode(183, 0)).setHardness(0.0F).setUnlocalizedName("scatterbomb").setTextureName("ScatterBombExplodeBottom").setCreativeTab(TNT.TNTTab);
	//public static Block Napalm = (new BlockNapalm(184, 0)).setHardness(0.0F).setUnlocalizedName("napalm").setTextureName("FirebombTop").setCreativeTab(TNT.TNTTab);
	// static Block Firebomb = (new BlockFirebomb(185, 0)).setHardness(0.0F).setUnlocalizedName("firebomb").setTextureName("NapalmBottom").setCreativeTab(TNT.TNTTab);
	
	@EventHandler
	public void load(FMLInitializationEvent event)
	{ 
		proxy.registerRenderInformation();
		LanguageRegistry.instance().addStringLocalization("itemGroup.Structures", "en_US", "Structures");
	
	 // GameRegistry.registerBlock(Firebomb);
	 // GameRegistry.registerBlock(Miner);
	  GameRegistry.registerBlock(Nuke, "Nuke");
	 // GameRegistry.registerBlock(Napalm);
	 // GameRegistry.registerBlock(ScatterBomb);
	 // GameRegistry.registerBlock(ScatterBombExplode);
	 
	//  LanguageRegistry.addName(TNT.Miner, "Miner TNT");
	//  LanguageRegistry.addName(TNT.Firebomb, "Firebomb");
	  LanguageRegistry.addName(TNT.Nuke, "Nuke");
	//  LanguageRegistry.addName(TNT.Napalm, "Napalm");
	//.addName(TNT.ScatterBombExplode, "ScatterBomb");
	  
	//  GameRegistry.addRecipe(new ItemStack(Miner, 1), new Object[] {"X#X", "#Y#", "X#X", 'X', Item.ingotIron, '#', Block.wood, 'Y', Block.tnt});
	//  GameRegistry.addRecipe(new ItemStack(Firebomb, 1), new Object[] {"#X#", "XPX", "#X#", 'X', Item.bucketLava, '#', Item.redstone, 'P', Block.tnt});
	  GameRegistry.addRecipe(new ItemStack(Nuke, 1), new Object[] {"#X#", "X#X", "#X#", 'X', Items.gunpowder, '#', Blocks.tnt});
	//  GameRegistry.addRecipe(new ItemStack(Napalm, 1), new Object[] {"XXX", "X#X", "XXX", 'X', Item.bucketLava, '#', Block.tnt});
	//  GameRegistry.addRecipe(new ItemStack(ScatterBomb, 1), new Object[] {"#X#", "XPX", "#X#", 'X', Block.tnt, '#', Item.gunpowder, 'P', Nuke});
      
	  //23 t/m 40 en 101 t/m 119 zijn nog vrij!!
	//  EntityRegistry.registerGlobalEntityID(EntityFirebomb.class, "Firebomb", 30);
	// 	LanguageRegistry.instance().addStringLocalization("entity.Firebomb.name", "Firebomb");
	 	
	 	EntityRegistry.registerGlobalEntityID(EntityNuke.class, "Nuke", EntityRegistry.findGlobalUniqueEntityId());
	 	LanguageRegistry.instance().addStringLocalization("entity.Nuke.name", "Nuke");
	 	
	 	//EntityRegistry.registerGlobalEntityID(EntityMiner.class, "Miner", 32);
	 	//LanguageRegistry.instance().addStringLocalization("entity.Miner.name", "Miner TNT");
	 	
	 	//EntityRegistry.registerGlobalEntityID(EntityNapalm.class, "Napalm", 33);
	 	//LanguageRegistry.instance().addStringLocalization("entity.Napalm.name", "Napalm");
	 	
	 	//EntityRegistry.registerGlobalEntityID(EntityScatterBomb.class, "ScatterBomb", 34);
	 	//LanguageRegistry.instance().addStringLocalization("entity.ScatterBomb.name", "ScatterBomb");
	 	
	 	//EntityRegistry.registerGlobalEntityID(EntityScatterBombExplode.class, "ScatterBombExplode", 35);
	 	//LanguageRegistry.instance().addStringLocalization("entity.ScatterBombExplode.name", "ScatterBombExplode");
	
	}
}
